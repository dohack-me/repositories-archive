# Shikanoko but it's a Markov chain

This was forked from https://github.com/nyraa/shikanoko-markov-chain